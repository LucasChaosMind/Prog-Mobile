package io.explain.mytravel.models

data class LocationData(val latitude: Double, val longitude: Double, val description: String)
