package io.explain.provalucasbresolino

import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.icu.number.IntegerWidth
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import java.lang.StringBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var eTCod : EditText
    private lateinit var eTCity : EditText
    private lateinit var eTQty : EditText

    private lateinit var localBD : SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        eTCod = findViewById( R.id.eTCod )
        eTCity = findViewById( R.id.eTCity )
        eTQty = findViewById( R.id.eTQty )

        localBD = SQLiteDatabase.openOrCreateDatabase( this.getDatabasePath( "dbfile.sqlite" ), null )
        localBD.execSQL( "CREATE TABLE IF NOT EXISTS gaspower ( _id INTEGER PRIMARY KEY AUTOINCREMENT, gascod TEXT, city TEXT, qty TEXT)" )

    }

    fun btPesq(view: View){

        Intent( this, PesqActivity::class.java ).let {
            register.launch( it )
        }
    }

    fun brInclude(view: View){
        val data = ContentValues();
        var gascod = eTCod.text.toString().toInt()
        var city = eTCity.text.toString()
        var qty = eTQty.text.toString()

        if((gascod.toDouble() > 0 && gascod.toDouble() < 5) && (!city.isNullOrEmpty()) && (qty.toDouble() > 0)){
            data.put( "gascod", gascod)
            data.put( "city", city)
            data.put( "qty", qty)

            localBD.insert( "gaspower", null, data )


            Toast.makeText( this, "Nova Inclusão", Toast.LENGTH_SHORT ).show()

            clean()
        }

        Toast.makeText( this, "Os Campos não podem ser nulos.\nO Cod. Combustivel deve ser valido!", Toast.LENGTH_SHORT ).show()

    }

    fun btMostrar(view: View){
        val cursor = localBD.query( "gaspower", null, null, null, null, null, null )

        var varGasPower = 0;

        var varGasLitros = 0.0;

        while ( cursor.moveToNext() ) {
            varGasPower += 1;
            varGasLitros += cursor.getString( 2 ).toString().toDouble();
        }
        Toast.makeText( this, "Qty de Abastecimento: ${varGasPower}.\nTotal Litros: ${varGasLitros}", Toast.LENGTH_SHORT ).show()
    }

    fun clean() {
        eTCod.setText( "" )
        eTCity.setText( "" )
        eTQty.setText( "" )
    }

    val register = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult() ) {
            result: ActivityResult ->
        if ( result.resultCode == RESULT_OK ) {
            result.data?.let {
                val cod = it.getStringExtra( "cod")
                eTCod.setText( cod )
            }
        }
    }
}