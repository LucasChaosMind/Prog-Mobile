package io.explain.provalucasbresolino

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PesqActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pesq)
    }

    fun Gasolina(){
        returnCodPesqIntent(1)
    }

    fun Etanol(){
        returnCodPesqIntent(2)
    }

    fun Diesel(){
        returnCodPesqIntent(3)
    }

    fun Natural(){
        returnCodPesqIntent(4)
    }

    fun returnCodPesqIntent(cod: Int){
        Intent().apply {
            putExtra( "cod", cod )
            setResult( RESULT_OK, this )
        }
        finish()
    }
}